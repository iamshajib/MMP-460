    <footer class="footer">
        <div class="container">
            <p class="text-muted">&copy; 2015 Christopher Stein
        </div>
    </footer>

    <?php wp_footer(); // js scripts are inserted using this function ?>
</body>

</html>